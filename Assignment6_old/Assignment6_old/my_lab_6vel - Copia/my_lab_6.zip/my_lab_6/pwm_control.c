/*
 * pwm_control.c
 *
 * Created: 7/27/2022 6:03:16 AM
 *  Author: IMDL_USER_8
 */ 

#include "pwm_control.h"

// Define the variables that need to run during the whole program execution

// "I_error" represents the cumulative error from the Integral controller and "P_error" represents the current error when the function was called
float I_error = 0.0;
float P_error = 0.0;

 // define the constants for proportional and integral controller. 
 // Fine tune these parameters
 float Kp_speed = 1;
 float Ki_speed = 0.01; 
 
 float Kp_pos = 1.0;
 float Ki_pos = 1.0;
 
 // define the duty cycle to be produced by the micro controller
 float dutycycle_speed = 0.0;
 float dutycycle_pos = 0.0;
 
 // need to check these values during testing
 #define RPM_2_TICKS 0.5
 #define POS_2_TICKS 1

uint32_t pi_speed_control(uint32_t current_speed, uint32_t target_speed)
{
	volatile float current_error;
	uint8_t level_tmp = 0;
	
	volatile float P_term = 0.0;
	volatile float I_term = 0.0;
	float i_max = 100.0;
	float i_min = -100.0;
	
	current_error = target_speed - current_speed;
	P_error = current_error;
	I_error = I_error + current_error;
	
	// Integral error control (a.k.a integral anti windup). In order to make sure the I_term doesn't increase to infinity
	if (I_error > i_max)
	{
		I_error = i_max;
	}
	else if (I_error < i_min)
	{
		I_error = i_min;
	}
	
	P_term = Kp_speed*P_error;
	I_term = Ki_speed*I_error;
	
	// Currently 10000 ticks configured as time period for the PWM functionality
	// We need to multiple the P and I terms with RPM_2_TICKS as output is not in percentage but ticks
	
	dutycycle_speed = (P_term + I_term)*RPM_2_TICKS + dutycycle_speed;
	
	if (dutycycle_speed > 100)
	{
		dutycycle_speed = 100;
	}
	else if (dutycycle_speed < 3)
	{
		dutycycle_speed = 3;
	}
	
	return (uint32_t)dutycycle_speed;
	
	// make sure the duty cycle lies within the period ticks (which is configured as 10000 here)
	
	
	level_tmp = (uint8_t)(dutycycle_speed/100.0);
	
	return level_tmp;
	
}


uint8_t pi_position_control(uint32_t current_position, uint32_t target_position)
{
	float current_error;
	uint8_t level_tmp = 0;
	
	float P_term = 0.0;
	float I_term = 0.0;
	float i_max = 100.0;
	float i_min = -100.0;
	
	current_error = target_position - current_position;
	P_error = current_error;
	I_error = I_error + current_error;
	
	// Integral error control (a.k.a integral anti windup). In order to make sure the I_term doesn't increase to infinity
	if (I_error > i_max)
	{
		I_error = i_max;
	}
	else if (I_error < i_min)
	{
		I_error = i_min;
	}
	
	P_term = Kp_pos*P_error;
	I_term = Ki_pos*I_error;
	
	// Currently 10000 ticks configured as time period for the PWM functionality
	// We need to multiple the P and I terms with POS_2_TICKS as output is not in percentage but ticks
	
	dutycycle_pos = (P_term + I_term)*POS_2_TICKS + dutycycle_pos;
	
	// make sure the duty cycle lies within the period ticks (which is configured as 10000 here)
	if (dutycycle_pos > 10000)
	{
		dutycycle_pos = 10000;
	}
	else if (dutycycle_pos < 3)
	{
		dutycycle_pos = 3;
	}
	
	level_tmp = (uint8_t)(dutycycle_pos/100.0);
	
	return level_tmp;
	
}